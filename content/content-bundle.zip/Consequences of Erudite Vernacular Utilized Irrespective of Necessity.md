Author: Danny Oppenheimer

“Consequences of Erudite Vernacular Utilized Irrespective of Necessity: Problems with Using Long Words Needlessly,” he showed that couching familiar ideas in pretentious language is taken as a sign of poor intelligence and low credibility.”

