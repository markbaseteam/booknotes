---
Author:
Tags: History 
---

## Introduction
> ==Anti-Semitism is a certain perception of Jews, which may be expressed as hatred toward Jews.== Rhetorical and physical manifestations of anti-​Semitism are  directed toward Jewish or non-Jewish individuals and/​or their property, toward Jewish community institutions and religious facilities.
## Patterns of Discrimination

## Religious Anti-Semitism
> Pontius Pilate offered to free Jesus but the Jews refused, preferring that he release another.

> Christianity had no legal status and Christians were periodically persecuted.  Christianity was seen as a religion of women and slaves. Because of this, many  Christians would leave the religion for Judaism. To counter this, Church leaders  emphasized the role of the Jews in the Crucifixion.  Thus, ==the emphasis on the Crucifixion during this period was influenced by the  desire to prevent Christians from converting to Judaism.==

- 
## Anti-Zionism and Anti-Israeli Behavior and Sentiment
- The theory about Hitler was convinced because of a Muslim **isn't true.** Both Hitler and the Muslim Brotherhood were already anti-Semitic.

> From 1948 until the early 2000s, anti-Zionism was mostly initiated by Arab and Muslim nations, opposing Israel’s right of existence.

## Chapter 5


Related books:
[[The Jews: The Whole Truth]]
[[The Jewish Question]]
[[Mein Kampf]]