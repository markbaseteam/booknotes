---
Author: Austion Kleon
Tags: creativity
---
**Notes**
- Everyone will be original if you're stealing from one to another.
- Imitation>Emulate ![[02D-good-theft-vs-bad_fmt (2) 1.jpeg]]

- Do the work that you want. Not what you know.
- *If you felt the story or the song is too short, make a sequel in your head then compare it to the official sequel*

[[The Dip]]