---
Author: Gabriel Wyner
Tags: Study, Linguistics
---
Summary:

Takeaways:


## CHAPTER 1: Introduction: Stab, Stab, Stab
#### PRINCIPLE 1: MAKE MEMORIES MORE MEMORABLE
- We tend to forget foreign words because they sound weird and they don't have meaningful connections to us.
- There are 4 types of connection:

1. Structure
2. Sound
3. Concept
4. Personal Connection

- Forget about the English translation. Use imagery instead.
- Picture is more memorable than words. That's why we remember stories more than words only.

**How to Make a Foreign Word Memorable**
- Use the sounds of your language
- Turn the sounds into images
- Connect those images in your past experiences.
#### PRINCIPLE 2: MAXIMIZE LAZINESS
- Extra repetition doesn't help your long-term memory.
- Rote repetition is boring.
#### PRINCIPLE 3: DON’T REVIEW. RECALL.
- Testing > Studying

#### PRINCIPLE 4: WAIT, WAIT! DON’T TELL ME!
> Fortunately, we don’t need to be stressed to remember; we just need to be interested.
- We need to gamify our learning. We need challenges.
- The more the word reaches the tip of your tongue, the more it'll engrave in your brain once you remembered it.
#### PRINCIPLE 5: REWRITE THE PAST
> Feedback allows us to resuscitate forgotten memories and get the most out of our practice sessions.

- Spaced repetition helps your memory.
## CHAPTER 3: Sound Play
- Reading with English IPA helps your pronunciation.
- The accent is important.
**Back-Chaining: How to Get Ridiculous Words into Your Mouth**
- Read the long weird word backwards.

- Every language has a pattern in their sounds and words.

## CHAPTER 4: Word Play and the Symphony of a Word

Books related:
[[Moonwalking with Einstein]]

