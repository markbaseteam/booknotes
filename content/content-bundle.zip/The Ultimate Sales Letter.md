---
Author: Dan Kennedy
Tags: Sales, Copywriting
---
# Introduction
- Sales letters turn words into profits.
# Part 1: Before You Write a Word
### What to Do Before You Start Writing
- Why you should keep a swipe file:
> You do not need much creativity to write letters; you only need to be adept at recycling and reorganizing ideas, themes, words, and phrases.

Here are some general ideas that will help you get started:
 
- Don't be intimidated by the idea or process of writing. There's no magic or genius or Harvard degree required.
 
- Recognize the value and power of your unique understanding of your business, products, services, and customers. 

- Keep a swipe file.

- Think selling. If you have successful sales experience — terrific! If you don't have a “selling mentality,” get one! Get some good books on selling. Never forget that a sales letter is a sales presentation in print.

- Write. Don't worry about writing a letter from start to finish. Just write blocks of copy and stack them up. A lot of great sales letters are eventually put together with scissors and tape (or by cutting and pasting on the computer). Write!
 
- Avoid perfectionism.
# Part 2: The Kennedy System
- Writing a copy that sells is not a creative act. It is a mechanical process that uses a formula or a framework.

### Chapter 1: The Clay with Which to Mold
**STEP 1: ~~Get “Into”~~ the Customer**

> **The goal is understanding.** To persuade someone, to motivate someone, to sell someone, you really need to understand that person.

**The “10 Smart Market Diagnosis and Profiling Questions”**

1. **What keeps them awake at night**, indigestion boiling up their esophagus, eyes open, staring at the ceiling?
2. What are they **afraid** of?
3. What are they **angry** about? Who are they angry at?
4. What are their top three daily **frustrations**?
5. What **trends** are occurring and will occur in their businesses or lives?
6. What do they secretly, ardently **desire** most?
7. Is there a built-in **bias** to the way they make decisions?
8. Do they have their own **language**?
9. Who else is selling something **similar** to their product, and how?
10. Who else has tried selling them something similar, and how has that effort **failed**?

Once you identified your reader, then ask this question to yourself:
> What Is Most Important to Your Reader?

It's all about **them.** Not you.

If you visualize yourself as the business owner, ask these questions to yourself:
- What benefit to me or my company justifies the cost?
- How can I validate my judgment?
- How would I get the money to give? (What budget would it come out of? What other expense would have to be reduced to afford this new one?)

**STEP 2: ~~Get “Into”~~ the Offer**

- Emphasize the obvious benefit.
- Build a list of product/offer features and benefits

>People do not buy things for what they are; ==they buy things for what they do.==

**STEP 3: Create a Damaging Admission and Address Flaws Openly**
- Acknowledge the product's flaws and figure out why they won't respond.
- Honestly assess the disadvantages of your offer and face them.

## Chapter 2: Salmon Swimming Upstream
**STEP 4: Get Your Sales Letter Delivered**

**STEP 5: Get Your Sales Letter Looked At**
## Chapter 3: Eyes Wide Shut
**STEP 6: Get Your Sales Letter Read**

Headline ideas:
- They Didn't Think I Could ________, but I Did.
- Who Else Wants ________? 
- How ________ Made Me ________
- Are You ________?
- How I ________
- How ________ Made Me ________
- How to ________
- Secrets Of ________
- Thousands (Hundreds, Millions) Now ________ Even Though They ________
- Warning: ________
- Give Me ________ and I'll ________
- ________ ways to ________

**Tips for Mailings to Sell Products Directly**
- Use testimonials
- Use photographs because it outperforms illustrations
- Use a photograph to show them that the product is easy to use

## Chapter 4: I Want It, but Not That Much
**STEP 7: Beat the Bugaboo**

Three Letter Formulas That Let You Transcend Price Questions:

Formula #1: Problem-Agitation-Solution
Formula #2: Fortune-telling
Formula #3: Winners and Losers

## Chapter 5: How to Write Sales Pressure
**STEP 8: Motivate Action**

==Technique #1: Intimidation==
- Limited Number Available
- Most Will Buy (Bandwagon Effect)
- You Will Buy Only If …
- You Can Buy Only If …
- Only Some Can Qualify …

==Technique #2: Demonstrate ROI — Sell Money at a Discount==

==Technique #3: Ego Appeals==

==Technique #4: Strong Guarantee==
- Basic Money-Back Guarantee
- Refund and Keep the Premium
- Redundancy
- Free Trial Offer
- Make the Guarantee the Primary Focus of the Offer

==Technique #5: Be a Storyteller==

## Chapter 6: Finally, Pen to Paper, Fingers to Keyboard

**STEP 9: Write the First Draft**

**STEP 10: Rewrite for Strategy**
- A successful sales letter uses conversational English and slangs.

In the same sales letter, you can convey your basic sales message and promise:
 
- In a straightforward statement 
- In an example
- In a story, sometimes called a “slice of life”
- In testimonials
- In a quote from a customer, expert, or other spokesperson
- In a numbered summary

> Tip: ==never end a page with a completed sentence.==

**STEP 11: Rewrite for Style**
- Increase Readership by Improving Readability
- Use the First Paragraph as an Extended Headline
- Be entertaining, but don't be funny.
- Appeal to the Senses.
> your sales letter copy needs to make the reader visualize pictures and feel experiences.
- Use Big Impact Words and Phrases

## Chapter 7: On Every Road Whether More or Less Traveled, There Are Potholes

**STEP 12: Answer Questions and Objections**

**STEP 13: Spark Immediate Action**
How to get immediate response:
- Limited Availability
- Premiums
- Deadlines
- Multiple Premiums
- Discounts for Fast Response, Penalties For Slow Response
- Ease of Responding

## Chapter 8: Final Brushstrokes

**STEP 14: The Creative PS****
**STEP 15: Check the Checklists**
Go back to the 10 smart questions and here are some another questions to help:

- Did you answer all **10 Smart Questions** about your prospect? (In Step 1) 
- How many of the ten were you able to use? 
- Which of the ten did you decide to emphasize?
- **Are you writing to your reader about what is most important to him/her (not you)?**
- Did you build **a list of every separate Feature** of your product/offer? 
- **Did you translate the Features to Benefits?**
- Did you identify a **Hidden Benefit** to use?
- Did you identify the disadvantages of your offer and flaws in your product? 
- **Did you develop “damaging admission copy” about those flaws?** 
- Did you make **a list of reasons not to respond?** 
- Did you raise and respond to the reasons not to respond? 
- Did you give careful thought to **getting your letter delivered** and/or through gatekeepers to its intended recipient? 
- Did you look at, compare, and consider different **envelope faces**?
- Did you picture your piece in a stack of mail held by your recipient, sorting it over a wastebasket? … and take care to survive the sort and **command attention and pique interest immediately upon being opened**?
- Did you craft the best possible headline for your letter?
- Did you craft the best possible subheadlines to place throughout your letter?
- Did you make careful choices about your **presentation of price**?
- Were you able to **sell money at a discount**?
- Were you able to incorporate **intimidation** into your call to action copy? 
- Were you able to appeal to the **ego** of your buyer?
- Did you develop and present a strong **guarantee**?
- Overall, did you tell an interesting **story**? 
- Did you use an interesting story about yourself?
- Did you write to the right length? (Not longer than need be due to poor or sloppy editing, but not shorter than necessary to deliver the best presentation?)
- **Did you use Double Readership Path?**
- **Did you use Internal Repetition?**
- Did you **keep the reader moving**, with yes-momentum and end-of-page carryovers?
- Did you bust up paragraphs, keep one idea per paragraph, and make the letter easily **readable**? 
- Were you interesting and entertaining? … **Is the letter enjoyable to read**?
- Did you use **five-senses word pictures**? 
- Did you choose words carefully, consider options of one word versus another, and create **high-impact phrases**?
- Did you make your copy personal **and conversational** (not institutional)?
- Did you go back through your copy and think of the possible questions or objections it might leave **unanswered**? … then find ways to ask them, raise them, and answer them? (Leave no unanswered questions!) 
- Did you choose and use devices to create **urgency** and spark immediate action? 
- Did you write at least one PS at the end of the letter for a strategic purpose?

**STEP 16: Use Graphic Enhancement**

27 Essential Copy Cosmetic Enhancements:

1. Boldfacing
2. Borders
3. Capitalization
4. Captions
5. Cartoons, comics, and carictures
6. Color
7. Columns
8. Drop Caps
9. Fonts and Typefaces [^1]
10. Highlighting
11. Indenting
12. Italics
13. Line Justification
14. Line Spacing
15. Lists
16. Personalization
17. Photographs and Illustrations
18. Screen Tints
19. Short Words, Sentences, and Paragraphs — Short. Delivers.
20. Sidebars — Sidebars help hold together — and differentiate — blocks of copy
21. Simulated Hand-Drawn Doodles
22. Simulated Handwritten Margin Notes
23. Simulated Rubber Stamps
24. Subheads
25. Text Boxes
26. Underscoring/Underlining
27. White Space

**STEP 17: Rewrite for Passion! Edit for Clarity!**
- A sales letter needs an enthusiastic personality

==Exercise==: Write to a person and convince them with something.

> ==If you can't romanticize your product or service or its direct benefits, you've got to be able to create excitement out of the feelings of owning it or using it, or the enjoyment of the money or time it saves.== Find something for the reader to get excited about! [^2]

> Cut out the parts the reader tends to skip. — Elmore Leonard

**STEP 18: Compare Your Draft to Examples**

## Chapter 9: The End Is Near
**STEP 19: Pretest**
- No-Cost Pretesting
- Read the Letter Aloud
- Read the Letter to Several People Who Might Be Typical Customers for the Offer
- Have a Young Child Read the Letter Aloud to You

**STEP 20: Bring Your Letter to Life**
**STEP 21: Change Graphic Enhancements**
**STEP 22: Edit Again**
**STEP 23: Mail a Mockup**
**STEP 24: The Cool-Off**
**STEP 25: Get Second Opinions**
**STEP 26: Give It the Final Review**
**STEP 27: Go to Press**

## Chapter 10: Major-League Play
**STEP 28: Test**

Format:

Headline A with:
Photo #1
Photo #2
Offer #1 and Photo #1
Offer #1 and Photo #2
Offer #2 and Photo #1
Offer #2 and Photo #2
Photo #1 and Offer #1 and Bonus #1
Photo #1 and Offer #2 and Bonus #1
Photo #1 and Offer #1 and Bonus #2
Photo #1 and Offer #2 and Bonus #2
Etc.

**STEP 29: Sometimes, Outsourcing**

# Part 3: The Most Versatile Sales Tool of All
### Chapter 11: Using Sales Letters in Business

## Chapter 12: The Million-Dollar Sales Letter Secret: The Power of a Sequence

## Chapter 13: “High-Tech” Sales Letters



---
Books Mentioned:
[[Psycho-Cybernetics]]
[[The Secret of the Ages]]
[[Winning Through Intimidation]]
[[Words That Sell]]
[[More Words That Sell]]
[[Roget's Super Thesaurus]]
[[Roget's Descriptive Word Finder]]
[[No B.S. Marketing Letter]]
[[The Ultimate Marketing Plan]]
[[Make 'Em Laugh & Take Their Money: On Using Humor as a Speaker, Writer or Sales Professional.]]

[^1]: Times Roman, Courier — for print marketing, and use sans-serif fonts — for example, Arial, Verdana — for online marketing. Consider using handwriting fonts for added personality.
[^2]: Here's an exercise I suggest you try: Assume you're writing a letter to someone with whom you're having an illicit affair. In the letter, you're going to convince your lover — who is slightly more conservative than you are, but who has shown signs of having a wild side — to take an entire week off to be with you. You must convince the person to make some excuse to be away from work and responsibilities for that week, to take all the risks inherent in this action in order to sneak away to the Bahamas with you — where you will have free use of a friend's villa, right on the beach. Use as many pages as you like. (You've got a sales job and a half here!) You can be bold, daring, even shocking. You can be poetic; you can be romantic; you can be colorful in your descriptions of the sun, the sea, the land, the stars, the breeze, the ocean smell. Where will you go? What will you do when you get there? Anticipate the objections and eliminate them as you go. Make huge promises! Create an overwhelming desire in your reader to go with you on that trip — no matter what the risk!