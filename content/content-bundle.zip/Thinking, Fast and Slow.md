---
Author: Daniel Kahneman
Tags: psychology, leadership, business
---

![[61fdrEuPJwL.jpg]]

## Part I. Two Systems
- **System 1**: it operates automatically with little or no effort (Fast Thinking)
	- It's biased to believe and confirm.
	- Links a sense to *Cognitive of Illusion* to *Illusions of Truth*.
	- Prone to respond to losses than gains. (loss aversion)
- **System 2**: it operates with an effort associated with concentration, agency, and choice. (Slow Thinking)
- You can't avoid recognizing ideas like the answer of 2+2 and the capital of the United Kingdom.
- Everyone is aware of their limited attention.
- The illusion of thought is called *cognitive illusion*.
> The best we can do is a compromise: ==learn to recognize situations in which mistakes are likely and try harder to avoid significant mistakes when the stakes are high.==
- The pupils are sensitive to the mental effort that's why they dilate when exposed to solving digits. [^1] Pupils dilate too when you are interested.
- Cognitive effort and self-control are both forms of mental effort.
- Self-control needs attention and effort.
- The more energy you put into the first task, the less self-control you'll experience in the next task. It's called *ego depletion*. [^2] ^651e23
	- The experiment about Israeli Paroles show that ego depleted judges tend to not accept grants. That's why, the best time to negotiate with someone is after they eat.[^3]
- System 2 also decides whether to agree and control with the System 1's suggestion.
- The people who are confident with their answer in the bat and ball problem intuitively are wrong. The *Dunning-Kruger Effect* is shown in here.
> ==Intelligence is not only the ability to reason; it is also the ability to find relevant material in memory and to deploy attention when needed.==
- People who show self-control tend to have high intelligence. [^4]
- The System 2 can be lazy too like System 1.
- **Priming** works unconcious. It's like connecting to the experience or word that reminds you. %%to check%%
	- For example, in religious cults, the image of their God reminded them to be faithful.
- Repeated Experience + Clear Display + Primed Idea + Good Mood = **Cognitive Ease** 
	- **Cognitive Ease** = Feels Similar + Feels True + Feels Good + Feels Effortless
- To make people believe in falsehood, you have to repeat it. Because it's difficult to distinguish familiarity and truth.
- Repetition is needed to feel normal. Like forming a habit, repetition is needed too.
- **Halo effect** is a type of bias that is based on what we see to judge a person.
- The consistency of an information forms a good story, not the completeness.
- Biases of judgment and choice at **What You See Is All There Is** (WYSIATI)
	- *Overconfidence*
	- *Framing Effects*
	- *Base-Rate Neglect*
- WYSIATI ignores absent evidences and believes the evidences that is seen.
- Use a heuristic question  instead of a logical question.
- Heuristic means finding an approximate answer to a difficult question.
	>“If you can’t solve a problem, then there is an easier problem you can solve: find it.”—George Pólya, How to Solve It


[^4]: Researchers of University of Oregon conducted a research on children.
[^3]: Read more at Dan Pinker's book called "[[When]]"
[^2]: Check out Roy Baumeister's study about ego depletion to read further.
[^1]: For futher reading, check out professor Eckhard Hess from University of Michigan about his study for dilation of pupils.

## Part II. Heuristics and Biases
- **Anchoring Effect** occurs when making a particular value to the unknown quantity before estimating the quantity.
- **Availability Heuristic** or Availability Bias is a mental shortcut that relies on quick informations.
	- For example, when you show the product's features more, the buyer will less likely to buy it. You have to show it's features and connect that feature to the feeling. [^5]
- To prove that you understand a pattern of behavior is to reverse it.
>Images of a worse disaster do not come easily to mind.
- The media don't just interest the public, but shapes it too.
- Human beings created "risk" to become aware and to understand the dangers and uncertainty.
- **Availability Cascade** %%to search%%
> ==People without training in statistics are quite capable of using base rates in predictions under some conditions.==
- Look at the base rate of the probability before making a decision or an answer.
- Speaking of luck, Daniel Kahneman's equation for success is
	- *success = talent + luck*
	- *great success = a little more talent + a lot of luck*
- For example:
	- There are two golfers. In the first day, the first golfer scored more, than the second golfer. We can say the first golfer is more likely to be lucky than the other one. 
	
	- But in the second day, the second golfer scored more because he practiced and practiced. He doesn't care if he's unlucky. He cares for his improvement to overcome his unluck. Well folks, that's a *Growth [[Mindset]]* and his success is. [^7]
- **Regression** is 
	- Outcome = the factor that affects + the object that affects
- Intuitive predictions are usually biased and regressive. That's why it needs to be corrected.
- When a prediction is unbiased, it feels unsatisfying.
- When you predict a moderate validity, you'll never guess the outcome whether it is rare or far from it.


[^5]: At [[Start With Why]], having a clear why and clear benefits, will help you to connect more to the feelings of the customer.
[^7]: In James Clear's article [[Absolute Success is Luck. Relative Success is Hard Work.]], relative success is hard work.
## Part III. Overconfidence
- In Philip Rosenzweig's book, *[[The Halo Effect]]*, concludes that stories about success or failure, often exaggerates the impact of leadership style and management practices on the firm outcomes, thus their message ir rarely useful.
- Wrong predictions are inevitable because the world is just unpredictable.
- Subjective confidence is not an indicator of accuracy. (**Illusion of Validity**)
- Clinicians only know that they're skilled, but not their boundaries of their skill. True experts know their limits of knowledge. Because of the *unrecognized limits* of a skilled professional, they are often overconfident which creates the illusion of validity.
- Herbert Simon's definition of intuition is,
	> ==Intuition is nothing more and nothing less than recognition.==
- The mystery of knowing and without knowing is not a unique feature of intuition; it is the norm of mental life.
> Do not trust anyone—including yourself—to tell you how much you should trust their judgment.
- Intuitions can't be trusted in an environment where stable regularities is sufficient or absent.
- Expertise is a collection of skill.
- **Planning Fallacy** is a scenerio where you create an unrealistic plan that is similar to best case scenarios.
- **Illusion of Control** means that you link your behavior to the uncontrollable outcome thinking it was you who controlled it.

## Part IV. Choices
- **Bernoulli's Error** is 
- **Prospect Theory**
- We usually avoid losing or not achieving a goal than achieving it.
- **Endowment Effect** occurs when the higher the demand, the higher the price. This is a part of economic theory.
- Bad doings attract more attention than good. That's why *bad is stronger than good*.
- Vivid imagination often overestimates the probability of a rare event.
- Regret and blame are not the same. 
- Both problems can be real. It depends on the way it frames it, the meaning will change.
## Part V. Two Selves
> ==The easiest way to increase happiness is to control your use of time.== Can you find more time to do the things you enjoy doing?
- The **Focusing Illusion** is described in one sentence,
> ==Nothing in life is as important as you think it is when you are thinking about it.==
> The focusing illusion can cause people to be wrong about their present state of well-being as well as about the happiness of others, and about their own happiness in the future.
- **James Dean Effect** is like in this part, "==It does not make sense to evaluate an entire life by its last moments==, or to give no weight to duration in deciding which life is more desirable." 
- Even though humans are *not irrational*, they also need to make better and accurate decisions.


For futher reading:
[[The Invisible Gorilla]]
[[Attention and Effort]]
[[Flow]]
[[An Enquiry Concerning Human Understanding]]
[[Strangers to Ourselves]]
[[Mind at Ease Puts a Smile on the Face]]
[[The Black Swan]]
[[The Atlantic]]
[[Stumbling on Happiness]]
[[The Wisdom of Crowds]]
[[Regression towards Mediocrity in Hereditary Stature]]
[[Sources of Power]]
[[The Halo Effect]]
[[A Random Walk Down Wall Street]]
[[Expert Political Judgment: How Good Is It? How Can We Know?]]
[[Clinical vs. Statistical Prediction: A Theoretical Analysis and a Review of the Evidence.]]
[[A Checklist Manifesto]]
[[Sources of Power]]
[[Blink]]
[[Choice and Consequence]]
[[Principles of Morals and Legislation]]
[[Free to Choose]]
[[Nudge]]


---
### Bonus:

**How to Write Persuasive Letters**
- Use high-quality papers to maximize the contrast between text and background.
- Use bright blue or red.
- Avoid using complex language. Use plain language only.
- Make it memorable by accompanying it with a familiar verse.
- Make the name easy to read.

**How to Get More Sales**
- When selling expensive products, don't pair it with a cheap product. Because *less is more*.
- When a product involves fruits ro vegetables, label them natural.
- 
**How to Teach Effectively**
- When teaching, surprise your students. Don't show them the statistics. Let them engage to the lesson instead.[^6]

**How to Build a Successful Company**
- Missions and visions aren't enough. You can't predict what will the company face.
> And even if you had perfect foreknowledge that a CEO has brilliant vision and extraordinary competence, you still would be unable to predict how the company will perform with much better accuracy than the flip of a coin.

**How to Hire The Best Person**
- First, identify the traits that functions and needed to be successful at the position.
- You can assess them by using some factual questions.
- Those questions must a scale (for example 1-5).

**How to Make an Experience More Memorable**
- Enjoy the experience, instead of taking many photos.
- Make the end of the experience more enjoyable and more memorable.



[^6]: In Nisbett and Borgida made a summarized statement coming from their study, "Subjects’ unwillingness to deduce the particular from the general was matched only by their willingness to infer the general from the particular."

