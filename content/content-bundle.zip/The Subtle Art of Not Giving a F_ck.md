---
Author: Mark Manson
Tags: philosophy
---
![[71QKQ9mwV7L.jpg]]

## Chapter 1: Don't Try
- Charles Bukowski is an example of someone who *never tried to be someone* and someone who *did not become a better person after fame and success.*
- In Texas, there's a saying that goes, 
> The smallest dog barks the loudest.
- It means that you don't need to show everybody that you're that someone. For example, a confident man doesn't need to convince people that he's confident. As a stoic quote said, "Don't tell. Just show." 
> ==The key to a good life is not giving a fuck about more; it’s giving a fuck about less, giving a fuck about only what is true and immediate and important.==
##### The Feedback Loop from Hell
>The	desire for more positive experience is itself a negative experience. And, paradoxically, ==the acceptance of one’s negative experience is itself a positive experience.==

> You will never be happy if you continue	to search for what happiness consists of.	You will never live if you are looking	for the meaning of life.—Albert Camus
- Don't try to look for happiness. The more you search for it, the more lonelier you feel.
- Have you ever noticed that when you care less about something, you do better at it? For example, the more boredom you pursue when making a habit, the more the habit sticks. [^1]
> Suffering through your fears and anxieties is what allows you to build courage and perseverance. [^2]

##### The Subtle Art of Not Giving a Fuck
***Subtlety #1***: *Not giving a fuck does not mean being indifferent; it means being comfortable with being different.*
- We must give a fuck at something. It's part of our biology.
- The point is; it's not giving a fuck about adversity.
> The point isn’t to get away from the shit. The point is to find the shit you enjoy dealing with.

***Subtlety #2***: *To not give a	fuck about adversity, you must first give a fuck about something more important than adversity.*

***Subtlety #3***: *Whether you realize it or not, you are always choosing what to give a fuck about.*

##### So	Mark, What  the Fuck Is the Point of This Book Anyway?
- The book will help you to think more clearly about choosing what to prioritize.
- It will help you too to lose and to let go.

## Chapter 2: Happiness Is a Problem
> There is a premise that underlies a lot of our assumptions and beliefs.
##### The Misadventures of Disappoinment Panda
- Suffering is biologically useful.
- The brain can't differentiate the physical pain and psychological pain.
- Emotional pains makes us to not repeat the same mistake. Humans usually wants to avoid the same mistakes than achieving its goal. [^3]
- Problems never stop. They improve. Or change.

##### Happiness Comes from Solving Problems
- Problems never go away in one's life. Life is not itself without obstacles.
> ==True happiness occurs only when you find the problems you enjoy having and enjoy solving.==
-  People fuck their problems with these two ways:
	1. Denial - denies their problems exist
	2. Victim Mentality - blaming
##### Emotions Are Overrated
> ==Whatever makes us happy today	will no longer make us happy tomorrow==, because our biology always needs something more.
- **Hedonic Treadmill** is an idea that we are always working hard to change our situation, but we never feel any change.
- What makes us feel good, will make us feel bad too.
	- Your dream university is the university you hate.

##### Choose Your Struggle
- Everybody knows the answer to "What do you want out of life?", but don't have the answer to "What *pain* do you want in life?".

## Chapter 3: You Are Not Special
- Self-esteem is not measured by how positive the feeling is. It's measured by how people feel about their negative aspects in their lives.
##### Things Fall Apart
- Entitlement plays out in two ways:
1. I suck. I deserve to be better.
2. I'm awesome. I deserve to be better.
##### The Tyranny of Exceptionalism
- To be great at something, you must dedicate hours and energy to that something.
##### B-b-b-but, If I’m Not Going to Be Special or Extraordinary, What’s the Point?
- If everyone were special, then no one would be special.
- The people who's truly exceptional at something does not believe they're exceptional. This is known as a *Dunning-Kruger Effect*. They become exceptional by becoming obsessed with improvement.

## Chapter 4: The Value of Suffering
##### The Self-Awareness Onion
**1st Layer**: The first layer of the self-awareness onion is a simple understanding of one’s emotions.
**2nd Layer**: The second layer of the	self-awareness onion is an ability to ask	why we feel certain emotions.
- Questioning the roots of the emotions helps us to understand our emotions.
##### Rock Star Problems
- External achievements can't satisfy your internal self.
>If you want to change how you see your problems, ==you have to change what you value and/or how you measure failure/success.==
##### Shitty Values
*Common values that creates poor problems:*
1. **Pleasure.**
- Pleasure is temporary. Chasing for pleasure makes you horrible.
2. **Material Success.**
- Self-worth is not measured by material things. Prioritizing this can make your values blind.
3. **Always Being Right.**
- A human can't rationalize everything. Learn to be like Socrates. *He who does not know everything but his ignorance.*
4. **Staying Positive.**
> Denying negative emotions leads to experiencing deeper and more prolonged negative emotions and to emotional dysfunction.
- Stop toxic positivity.

##### Defining Good Values
- *Good values are:*
1. *reality-based*
2. *socially destructive*
3. *immediate and controllable*
- *Bad values are:*
1. *superstitious*
2. *socially destructive*
3. *not immediate and controllable*
> What are the values that you prioritize above everything else, and that therefore influence your decision-making more than anything else?

### Chapter 5: You Are Always Choosing
##### The Choice
- We can't always control what is happening to us. But we can control how we respond to the situation. A *stoic* move indeed. It's like in [[The Laws of Human Nature]].
##### The Responsibility/Fault Fallacy
>==Nobody else is ever responsible for your situation but you.==

> ==To simply blame others is only to hurt yourself.==
##### Responding to Tragedy
- We are responsible for our feelings, beliefs and actions.
##### Genetics and The Hand We're Dealt
- When something happened that we can't control, it's true that it's not their fault. But they're responsible.
##### Victimhood Chic
- The media tell stories to outrage people to have money, than to tell the truth. According to Daniel Kahneman's book, [[Thinking, Fast and Slow]], the media shapes us.
##### There Is No "How"
- Choose what to give fuck about something. Simple. But not easy.

## Chapter 6: You're Wrong At Everything (But So Am I)
##### Architects of Our Own Beliefs
##### Be Careful What You Believe
##### Th Dangers of Pure Certainty 
> The only way to solve our problems	is to first admit that our actions and	beliefs up to this point have been wrong and are not working.
##### Manson's Law of Avoidance
- Manson's Law: *The more something	threatens your identity, the more you	will avoid it.*
##### Kill Yourself
- In "*Choose to measure yourself not as some horrible victim or dismal	failure. Instead, measure yourself by more mundane identities: a student,	a partner, a friend, a creator.*" it reminds me of a part in [[Atomic Habits]] that has a similar idea; to create a habit, you have to focus on *who you wish to become* (Identity-Based Habit).
##### Be a Little Less Certain of Yourself
## Chapter 7: Failure is The Way Forward
##### The Failure/Success Paradox
> ==If someone is better than you at something, then it’s likely because she	has failed at it more than you have.==
- We can only be successful if we're willing to fail at something over and over again.
##### Pain is Part of The Process
##### The "Do Something" Principle
## Chapter 8: The Importance of Saying No
##### Rejections Make Your Life Better
##### Boundaries
##### How to Build Trust
##### Freedom Through Commitment
> ==Commitment gives you freedom	because you’re no longer distracted	by the unimportant and frivolous.==
## Chapter 9: ...And Then You Die
##### Something Beyond Ourselves
##### The Sunny Side of Death
>==The fear of death follows from the fear	of life. A man who lives fully is prepared to die at any time.==—Mark Twain
---
For Further Reading:
[[The Denial of Death]]

[^1]: In [[Atomic Habits]], professionals master the boredom and professionals care for something that is necessary.
[^2]: That's why [[Obstacle is The Way]].
[^3]: In Daniel Kahneman's book, [[Thinking, Fast and Slow]], he explained that further.