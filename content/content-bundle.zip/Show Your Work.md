---
Author: Austin Kleon
Tags: creativity
---

![[71MTgEEjNVL 1.jpg]]

## 1. You Don't Have To Be A Genius.

##### Find a Scenius
- Find someone who shares your interest. 
	- If [[Steal Like an Artist]] is about stealing influence frm other people, **Show Your Work** is about influencing people to *steal your work*.
	- Instead of asking ourselves, what can we do for others, ask ourselves *what can we contribute to others*.
	- We can easily find scenius on the internet.

##### Be an Amateur
> “In the beginner’s mind,	there	are	many	possibilities. In the	expert’s	mind, there	are few.”—Zen Shunryu Suzuki
 -  Because amateurs are not afraid to make mistakes, unlike experts. It's like having a growth mindset instead of a fixed mindset.[^1]
 - Amateurs know that contributing is more important than doing nothing.
 - Use the tools that are available to you to create ideas.
>   ==The best way to get started on the path to sharing your	work is to think	about what	you want to learn, and	make a commitment	to	learning it in	front of others.==
 - Find a scenius and find out *the thing that they're not sharing* and learn from it. Try it. Embrace your amateurism. Learn from your mistakes, share what you love and people who love what you love will find you.
 
##### You Can't Find Your Voice If You Don't Use It.
- Your voice will follow once you talk about what you love.
- If you want to get discovered, share your work.

##### Read Obituaries
> “Remembering that I’ll be dead soon is	the most important tool I’ve ever encountered to help me make the big	choices in life. Because almost everything—all external expectations,	all pride, all	fear of	embarrassment or	failure—these	things just fall away in the face of death,	leaving only what is truly important. ==Remembering	that	you	are going to die is the best	way	I know to avoid the trap of	thinking you have something to lose.==You	are already naked.”—Steve Jobs
---
## 2. Think Process, Not  Product.
- Don't focus on the Outcome. Instead, focus on the system.[^2]
##### Take People Behind The Scenes.
- Take advantage of the internet. Upload about things what you're working on, your process or your unfinished work.
- Talk about your influences, your little bit piece of work, and etc.
##### Become a Documentarian of What You Do
> But whatever	the	nature	of	your	work, there	is	an	art	to	what	you	do,	and	==there are people who would be interested in that art, if only you presented it	to	them in the right way.==
- Become a documentarian. 
	- Take many photos
	- Get a journal
	- Use audio recorders
	- Make a scrapbook
*It's purpose is to have a track of what you're doing.*
---
## 3. Share Something Small Everyday.
##### Send Out a Daily Dispatch.
- A daily dispatch is like a deleted scene in a movie or the behind the scenes.
- You can use social media as a daily dispatch.
##### The "So What" Test
> Ideally,	you want	the work you post online to be copied and spread to	every corner of the Internet,	so ==don’t post things online that you’re not	ready for everyone in the world to	see.==
- Sharing ≠ Over sharing
##### Turn Your Flow Into Stock.
- Flow is by gathering and organizing ideas that eventually will turn into a product or stock.
##### Build a Good Domain Name
> Don’t think of your website as a self-promotion machine, think of	it as a self-invention machine. 


> ==Fill your website with your word and your	ideas and the stuff you care about.==
---
## 4. Open Up Your Cabinet of Curiosities.
##### Don't Be a Hoarder.
> Your	influences are all worth sharing because they clue people	in	to	who you are and what  you do—sometimes even more than your own	work.
##### No Guilty Pleasures.
> You have to	have the courage to keep loving your garbage, because what makes us unique is the diversity and breadth of our influences, the unique ways in which we mix up the parts of culture others have deemed “high” and the “low.”
- When you share your taste and influences, own it.
##### Credit is Always Due.
- If you're making a blog, link the source. Because people are lazy to search.
---
## 5. Tell Good Stories.
##### Work Doesn't Speak For Itself.
- An objects value can change when you deliver it with a good story. Start sharing it's benefits instead of  it's features. [^3]
- To share more effectively, you should become a good storyteller.
##### Structure is Everything.
- Dan Harmon's Story Circle
	1. A character is in a comfort zone.
	2. But they want something 
	3. They enter an unfamiliar situation
	4. Adapt to it
	5. Get what they wanted
	6. Pay a heavy price for it
	7. Return to their familiar situation
	8. Having changed
> A good pitch is set up in three acts: The first act is the past, the second act is the present, and the third act	is the future.
##### Talk about yourself at parties.
> The way to get over the	awkwardness in	these situations	is	to	stop	treating them as interrogations, and ==start treating them	as opportunities	to connect with somebody by honestly and humbly explaining what	it is that you do.==
---
## 6. Teach What You Know.
##### Share Your Trade Secrets.
> “The	impulse to keep to yourself what you have learned is not only shameful,	it	is	destructive. ==Anything you do not	give	freely and abundantly becomes	lost	to	you.== You	open your safe	and	find	ashes.”—Annie Dillard
- Teaching your techniques won't be mastered by others easily because it takes time. So, don't freak out.

> Teaching people	doesn’t subtract value from what you do, it actually adds to it.


---
## 7. Don't Turn Into Human Spam.
##### Shut Up and Listen.
- Human spams are those who are like narcissistic people that wants attention for them. As if the world is revolving around them. [^4]
-Open node is what Blake Butler calls when you're a connector. You have to give and get.
##### You Want Hearts, Not Eyeballs.
>Stop worrying about how many people follow you online and start worrying about the quality of people	who follow you.
- Be someone who's worth following to gain followers.
- To be *interesting,* you have to be *interested.*
##### Vampire Test
- Constantin Brancusi, a Romanian sculptor, practiced *Vampire Test* to people to decide who he should enter and leave his life.
	- Leave the person who's worn-out and don't have any values.
	- Let the person enter when he's still have energy.
	- This works too in hobbies, jobs, places and etc.
> “Part of the	act of creating is	in	discovering	your	own	kind. They are everywhere. But don’t look for them	in	the wrong places.”—Henry Miller
##### Identify Your Fellow Knuckleballers.
> These are your real peers—the people who share your obsessions, the people	who	share a similar mission to your	own, the people	with whom you share a mutual respect.
##### Meet Up In Meatspace.
- Go out and meet your online friends.
---
## 8. Learn To Take a Punch.
##### Let 'Em Take Their Best Shot.
 Here is the ugly truth;
> The more people come across your work, the more criticism you’ll face.
- But the more we receive criticisms, the more we'll realize they can't hurt you. 
- Every criticism is an opportunity to improve your work or even work something new.
- Your work is just your work. Don't take thing personally.
##### Don't Feed The Trolls.
- Care feedbacks for the people who care about you. Stop caring for trolls. [^5]
> ==A troll is a person who isn’t	interested in improving	your	work,	only	provoking you with hateful,	aggressive,	or	upsetting talk.==
> I have a pretty good mental firewall	that	filters what I let get to me.

---
## 9. Sellout.
##### Even The Renaissance Have To Be Funded.
- Get a second job to fund yourself. 
##### Pass Around The Hat.
> Beware of selling the	things that you love: When	people	are asked to get	out their wallets, you find out how	much	they	really value what you	do.
##### Keep A Mailing List
- Emails are near dead right? But everyone has their own email. That's why you should keep a mailing list.
- You can contact them by sending emails. 
- If people will signup for your mailing list;
	- Give them a list of what should they expect.
	- Respect their emails, don't spam them! 
##### Make More Work For Yourself.
- What matters  is doing good work and taking advantages of every opportunity.
##### Pay It Forward.
> ==You just have to be as generous as	you can, but selfish enough to get your	work done.==
---
## 10. Stick Around.
##### Don't Quit Your Show.
> Every career is full of ups and downs, and	just like with stories, when you’re in the middle of living out your life and career, you don’t know whether you’re up or down or	what’s	about to happen next.

> “If	you	want a	happy ending, that depends, of course, on	where you stop	your	story.”—Orson Welles

##### Chain-Smoke
- To avoid losing momentum, don't wait for anything else and stop  worrying for what's next. Use your old project to bring the next one to life.
##### Go Away So You Can Comeback. 
- You need a time for yourself in other to connect with others. As Ryan Holiday said, [^6]
> Sometimes we have to disconnect from the world to connect better %%To check%%


##### ~~Start Again~~ Begin Again
>  You	can’t be content with	mastery;	you	have to push yourself to become a	student again.

---

For further reading:
[[Cognitive Surplus]]
[[We Learn Nothing]]
[[Art and Fear]]
[[Significant Objects]]
[[Rework]]
[[Wherever I Wind Up: a Memoir]]
[[It Will Be Exhilarating]]

[^1]: [[Mindset]]
  [^2]: [[Atomic Habits]]
[^3]: [[Start With Why]]
[^4]: [[The Laws of Human Nature]]
[^5]: [[The Subtle Art of Not Giving a F*ck]]
[^6]: [[Stillness is The Key]]