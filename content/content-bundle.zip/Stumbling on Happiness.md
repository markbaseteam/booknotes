---
Author: Daniel Gilbert
Tags: psychology
---
![[StumblingOnHappiness-by-DanielGilbert.jpg]]

## Part 1: Prospection
##### Chapter 1: Journey to Elsewhen
- He said, "*We also know that the worse we do, the better we will be remembered.*"—it reminds me of "*Bad is Stronger than Good*" article in [[Thinking, Fast and Slow]].
- The greatest achievement in human brain is *conscious experience*.
- ***Predicting*** and ***Nexting*** are not the same.
> Small children cannot say what they want to be later ==because they don’t	really understand what later means.==
- One of the characteristics of a person whose frontal lobe is damaged is inability to think his or her own future.
- People find it easy to imagine an event and often overestimate the likelihood to occur the actual event. 
> Because most of us get so much more	practice imagining good than bad events, ==we tend to overestimate the likelihood that good events will actually happen to us, which leads us	to be unrealistically optimistic about our futures.==

>Apparently, ==gaining control can have a	positive impact on one’s health and well-being, but losing control can be worse than never having had any at all.==
- People who are immune to the *illusion of control* are generally depressed.

## Part II: Subjectivity
##### Chapter 2: The View from in Here
> Happiness really is nothing more or less than a word that we word makers can use to indicate anything we please.
- In which he said, "*Apparently, the describers’	verbal descriptions of their experiences “overwrote” their memories of the experiences themselves, and ==they ended up remembering not what they had experienced but what they had said about what they experienced.==*" has the same idea in [[Thinking, Fast and Slow]] in the chapter of *Experience and Memory* that said, "==*Confusing experience with the memory of it is a compelling cognitive illusion—and it is the substitution that makes us believe an experience can be ruined.*==" and "==*The mood of the moment depends primarily on the current situation.*=="
- **Stretching Experience** is a phenomenon in which person 1 experiences level 10 of happiness, and person 2 doesn't feel person 1's happiness.
> What we can say is that all claims of happiness are claims from someone’s point of view—from the perspective of a single human being whose unique collection of past experiences serves as a context, a lens, a background for her evaluation of her current experience.
##### Chapter 3: Outside Looking In
> research shows that physiological arousal can be interpreted in a variety of ways, and our interpretation of our arousal depends on what we believe caused it.
	- For example, fear can be mistaken as lust.
- People who are happy blink slowly.
- You can not measure one's feelings accurately.

## Part 3: Realism
##### Chapter 4: In the Blind Spot of the Mind's Eye
- The brain fills your blindspot with fake sceneries or ideas.
> Because those interpretations are usually so good because they usually bear such a striking resemblance to the world as it is constituted, we do not realize that we are seeing an interpretation.
- Humans like to fill their brain's blindspot with mental images that is similar to the situation, but not accurate.
> ==We see things that aren't there and we remember things that didn’t really happen.==
##### Chapter 5: The Hound of Silence
- Our inability of noticing the absence can make our decisions wrong.
- When we are choosing, we look for the positive. When rejecting, we look for the negative.
- We imagine detailed when the near is the future or the past is near. We abstractly imagine when it is far enough to happen.

## Part 4: Presentism
##### Chapter 6: The Future is Now
- When we ask people to describe about their past experiences, their description is mostly influenced by their current beliefs and experiences.
- How we feel when imagining the future event is a good indicator of how we will feel when that happens. But it is not a good guide to how we will feel when that happens.
> Future events may request access to the emotional areas of our brains, but current events almost always get the right of way.
- When we imagine that comes with emotional experience, it's called *prefeeling.* 
- Imagining with emotional experience vs. *mental imagery* are different.
 - We mistakenly believe that our feeling for tomorrow is the same as today. Same as the idea of [[The Subtle Art of Not Giving a F*ck]] that says, "*Whatever makes us happy today will no longer make us happy tomorrow*".
>  We assume that what we feel as we imagine the future is what we’ll feel when we get there, but in fact, ==what we feel as we imagine the future is often a response to what’s happening in the present.==
##### Chapter 7: Time Bombs
> Because ==we naturally use our present feelings as a starting point when we attempt to predict our future	feelings==, we expect our future to feel a bit more like our present than it actually will.
- Our present feeling and thinking influences influence on the way we'll think for the future.

## Part V: Rationalism
##### Chapter 8: Paradise Glossed
- Negative events truly affect us, but it's not long what you think.
- The **Serial Position Effect** has the idea that we can recall some things depending on the place. (not related to the book.)
- Humans are quite good at creating ways to see positive ways.
- The world is a mixture of reality and illusion.
> we seek positive views of our experience, but we only allow ourselves to embrace those views when they seem credible.
 - To ensure that our view is credible, our eyes tend to search for what the brain wants.
 ##### Chapter 9: Immune to Reality
> research suggests that people are typically unaware of	the reasons why they are doing what they are doing, but when asked for a reason, they readily supply one.
- We are not conscious when our views are changing because we are unaware of the process that takes the change.
- Research shows that people experience less pain when they expect to have something great in exchange. [^1]
> we cannot change the experience that	we look for ways to change our view of the experience
## Part VI: Corrigibility
##### Chapter 10: Once Bitten
> ==Our brains use facts and theories to make guesses about past events, and so too do they use facts and theories to make guesses about past feelings.==
>  We believe in our feelings as we believe we must have felt.
###### Chapter 11: Reporting Live from Tomorrow
> We don’t always see ourselves as superior, but we almostbalways see ourselves as unique.
- Why do we think we are special?
	1. We know ourselves more in inside.
	2. We assume that we are special.
	3. We experience our own thoughts and feelings.

Related Books:
[[Be Here Now]]
[[Candide]]

 [^1]: "research shows that when people are given electric shocks, they actually feel less pain when they believe they are suffering for something of great value."