---
Author: Eugene Schwartz
Tags: Marketing
---
## How to Channel Mass Desire Onto Your Particular Product
**Step # 1:** Choose the most powerful desire that can possibly he applied to your product.

- Every mass desire has three vital dimensions.
1. Urgency
2. Intensity
3. Degree of Demand to be satisfied.

- The choice of the problem or desire is the most important step in writing your ad.

**Step # 2:** Acknowledge that desire—reinforce it—and/or offer the  means to satisfy it—in a single statement in the headline of  your ad.

- Write the solution in the headline.
- If the customer knows your product, start the headline with the *product.*
- If the customer doesn't know your product, start the headline with the *desire*.
- If the customer doesn't know what he seeks but aware of his problem, start the headline with that problem and make it clear into a specific need.

**Step # 3:** And then you take the series of performances that are built into your product—what your product does—and you show your prospect how these product performances inevitably satisfy  that desire.
- Introduce your product and show what your product does and how the product solve the customer's problem.
- Every product that is given to you is actually two.
	 1. Physical product
	 2. Functional product

- The functional product is the product in action. What benefits can it give to the customer.

> ==The physical part of your product is of value only because  it enables your product to do things for people.==

> No physical part of your product can ever become a headline.

To document and reinforce the primary performance that you promise your reader in your headline, in the following ways:
1. *By justifying your price.*
2. *By documenting the quality of your performance.*
3. *By assuring your prospect that that performance will continue throughout the years.*
4. *By sharpening the reader's mental picture of that performance.*
5. *By giving your product's claim of performance  afresh new basis for believability.*

**Task:** List the number of different performances it contains and group the performances to solve their problems. 

Then, feature the one performance that will harness the greatest sales power onto your product at that particular time.

## YOUR PROSPECT'S STATE OF AWARENESS—HOW TO CAPITALIZE ON IT WHEN YOU WRITE YOUR HEADLINE
> Your ad always begins with your market, and leads that market inevitably into your product.

Your headline must concern the market first. Not your product or its performance.

The headline must based from the answers of these questions:

1. *What is the mass desire that creates this market?* (Which we have already discovered.)
2. *How much do these people know today about the way your product satisfies this desire?* (Their State of Awareness.)  
3. *How many other products have been presented to them before yours?* (Their State of Sophistication.)

- Your headline must hook your readers to read the second sentence of your ad.

> It is the copy writer's job to ==force the prospect to read his client's full story==—not just a skimmed version of it.

### What Your Prospect's State of  Awareness Demands From Your Headline
1. **The Most Aware** 

> The price is the most important  part of his headline.

2. **The Customer Knows of the Product But Doesn't Yet Want It**

- The *headline* must display:
	- the name of the product
	- the remainder of the headline points out its superiority

- The *body* must display:
	- the elaboration of the superiority that includes *documentation*, *mechanization*, and *visualization*.
	
The headline must face the 7 tasks:

(a) To reinforce your prospects desire for your product:  
- association
- illustration
- example
- sharpen sensory imagery

(b) To sharpen his image of the way your product satisfies that desire;  

(c) To extend his image of where and when your product satisfies that desire; 

(d) To introduce new proof, details, documentation of how  well vour product satisfies that desire;  

(e) To announce a new mechanism in that product to enable it to satisfy that desire even better;  

(f) To announce a new mechanism in vour product that eliminates former limitations;  

(g) Or to completely change the image or the mechanism of  that product, in order to remove it from the competition of other  products claiming to satisfy the same desire.

3. **How to Introduce New Products**
- The *headline* must display:
	- the desire
	- solution
	- proof

Attributes of a copywriter that he must have:
1. Analysis
2. Intuition
3. Verbal Creativity

4. **How to Introduce Products That Solve Needs**
- The *headline* must display:
	- name of the need/its solution
	- dramatize it to make the customer feel that he needs the solution
	- present the solution

5. **How to Open Up a Completely Unaware Market**

Eliminate these on your headline:
- price
- name of the product
- function (*the performance of your product, and the desire  it 
- satisfies, can only be brought in later.*)
- desire

You can only mention your **market.**

> You are writing an identification headline. You are selling nothing, promising  nothing, satisfying nothing.

- The *headline* must display:
	- their problem

> ==In effective advertising, though stvles may change, strategy does not.==

## THE SOPHISTICATION OF  YOUR MARKET:  HOW MANY PRODUCTS  HAVE BEEN THERE  BEFORE YOU?
### Stages of Customer Sophistication
**If You Are First in Your Market**
Your headline:

> ==Be simple. Be direct. Above all, don't be fancy.== 'Same either the need or the claim in your headline—nothing more. Dramatize that claim in your copy—make it as powerful as possible.  And. ==then bring in your product; and prove that it works==.

**If You're Second, Do This**
Your headline:

> If you're second, and the direct claim is still working—==then  copy that successful claim—but enlarge on it. Drive it to the absolute limit.== Outbid your competition.

**The Third Stage of Sophistication**
Your headline:
> ==What this market needs now is a new device to make all these old claims become fresh and believable to  them again.==

**The Fourth Stage**
Your headline:

> the elaboration is concentrated on the mechanism, rather than on the promise

> Simply elaborate or enlarge upon the successful mechanism. Make it easier, quicker, surer; allow it to solve  more of the problem; overcome old limitations; promise extra benefits.

> But remember, the mechanism vou use must not only be new and legitimate, but it must  be accepted as believable and significant by vour market.

**How to Revive a "Dead" Product**
Your headline:

> The emphasis shifts from the promise and the mechanism which accomplishes it, to identification with the prospect  himself.

## 38 WAYS TO STRENGTHEN  YOUR HEADLINE  ONCE YOU HAVE YOUR  BASIC IDEA
1. **Measure the size of the claim:** 

"20,000 FILTER TRAPS IN VICEROY!"  

"I AM 61 POUNDS LIGHTER . . ."  

"WHO EVER HEARD OF 17,000 BLOOMS  FROM A SINGLE PLANT?"

2. **Measure the speed of the claim:**

"FEEL BETTER FAST!"

3. **Compare the claim**
4. **Metaphorize the claim**
5. **Sensitize the claim by making the prospect feel, smell,  touch, see or hear it:**
"TASTES LIKE YOU JUST PICKED IT!"

"THE SKIN YOU LOVE TO TOUCH!"

6. **Demonstrate the claim by showing a prime example**
7. **Dramatize the claim, or its result**
8. **State the claim as a paradox:**

"HOW A BALD-HEADED BARBER SAVED MY HAIR!"

9. Remove limitations from the claim
10. Associate the claim with values or people with whom  the prospect wishes to be identified
11. Show how much work, in detail, the claim does
12. State the claim as a question
13. Offer information about how to accomplish the claim
14. Tie authority into the claim
15. Before-and-after the claim
16. Stress the newness of the claim
17. Stress the exclusivity of the claim
18. Turn the claim into a challenge for the reader
19. State the claim as a case-history quotation
20. Condense the claim—interchange your product and the  product it replaces
21. Symbolize the claim—replace the direct statement or  measurement of the claim with a parallel reality
22. Connect the mechanism to the claim in the headline
23. Startle the reader by contradicting the wav he thinks the  mechanism should work
24. Connect the need and the claim in the headline
25. Offer information in the ad itself
26. Turn the claim or the need into a case history
27. Give a name to the problem or need
28. Warn the reader about possible pitfalls if he doesn't use  the product
29. Emphasize the claim bv its phraseology—by breaking it  into two sentences, or repeating it, or a part of it
30. Show how easv the claim is to accomplish bv imposing  a imiversally-overcome limitation
31. State the difference in the headline
32. Surprise vour reader into realizing that former limitations have now been overcome
33. Address the people who can't buv your product
34. Address your prospect directly
35. Dramatize how hard it was to produce the claim
36. Accuse the claim of being too good
37. Challenge the prospects present limiting beliefs
38. Turn the claim into a question and answer

## SUMMARY: THE ART OF CREATIVE PLANNING—HOW TO MAKE AN IDEA GROW

## THE SEVEN BASIC  TECHNIQUES OF  BREAKTHROUGH  ADVERTISING: How to write body copy  as strong as your headline
- Your headline's job isn't to sell or identify your product—even the prospect's desire—the job is to make your prospect pause to read the body. 
- The body does the selling.

The length, structure, development, style and pace of your ad will depend on three factors:

1. how much copy you need to build his desire for that  product—and everything that product can do for him—to its  greatest possible strength.
2. how much additional copy you need to make him  feel both comfortable and complimented bv that product, to enable him to visualize that product as a part of the life structure  that he has built, and is building, for himself.
3. how much additional copy vou need to make  him believe what you have said—to compensate for his already existing prejudices and beliefs.

**The Three Dimensions of Thought and Feeling:**
1. Desire - The task is *intensify* their wants.
2. Identification -
Your tasks are:
- ==to make him feel the prestigious and select group he joins when he becomes a user of that product==. 
- To  picture for him the people who live in your product's world today.

3. Beliefs 
Your tasks:
- You build up from them  by using his kind of logic, not your own, to prove that vour product satisfies his desires
- to prove that your product works
- to prove that his kind of people rely on your product
- to prove that no other product satisfies his needs as well.

## THE FIRST TECHNIQUE OF BREAKTHROUGH COPY:  INTENSIFICATION

> Your job is to fill out these vague desires with concrete images—to show your prospect every possible way that they can be  fulfilled—to multiply their strength by the number of satisfactions  that you can suggest to achieve them.

The 2 Techniques to Fit your Message:
1. Compression - Cutting more words.
2. Campaign - Repetition of the words.
> You cannot repeat, but you can reinforce.

**Thirteen Ways to Strengthen Desire/ The Techniques for Intensification:**
1. Your First Presentation of Your Claims
- First present the product or the satisfaction it gives directly—bluntly—by a thorough, completely detailed description of  its appearance or the results it gives.
2. Put the Claims in Action
- To show, not only how the product looks, and what benefits it  gives the reader, hut exactly how it does this.

3. Bring In the Reader
- put your reader right smack in the middle of this product-in-action  story, and give him a verbal demonstration of as if it will happen to him the first day he owns that product.

4. Show Him How to Test Your Claims
- Turn the demonstration into a test. Let your reader  visualize himself proving the performance of your product—gaining its benefits immediately—in the most specific and dramatic  way possible.

5. Stretch Out Your Benefits in Time
6. Bring In an Audience
- At the end of this passage, other actors besides the reader  are brought into the scene. Each one of them—each group of  them—provides a fresh new perspective through which your  reader can view the product. Seen through their eyes—experienced through their actions and reactions—the product performances become new, vivid and completely different again

7. Show Experts Approving
8. Compare, Contrast, Prove Superiority
9. Picture the Black Side, Too
 - Thus you derive two currents of motivation—repulsion away  from the former problem or inadequate product, and the attraction generated by your own product's contrasting solutions.
 10. Show How Easy It Is to Get These Benefits
 11. Use Metaphor, Analogy, Imagination
 12. Before You're Done, Summarize
 13. Put Your Guarantee to Work
 - you can turn that guarantee into the climax of your ad—the last brief summary of your product's performances—reinforced at every step by the positive reassertion of that guarantee.

**How to Apply These Principles of Intensification to the Campaign**

> First, to compress that  image into a single statement or picture, so powerful that it will sell the product the very first time it is used, and so true to the  heart of your market that it will continue to sell that product, even when it is used over and over again.

> To present a series of variations or perspectives of that central image—each emerging from your dominant idea, but each so different from  the rest that they impel your prospect to read through them, and so fresh that they make that dominant idea seem new again.

## THE SECOND TECHNIQUE OF BREAKTHROUGH COPY: IDENTIFICATION