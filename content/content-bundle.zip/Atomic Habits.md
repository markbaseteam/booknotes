---
Author: James Clear
Tags: habits
---
![[4eb201ca3f2c670feb7102a56f258d66.jpg]]

## The Fundamentals
##### 1. The Surprising Power of Atomic Habits
> ==Habits are the compound interest of self-improvement.==

- Even if 1% is unnoticeable, it counts for the long run. 
- If you're thinking "*Where is the 1% if the result is unnoticeable?*" The 1% is stored for the big shift.
- Focus on your system instead of goals.
- Goals are your directions. Systems are your steps.
- The problems when goal is just the focus;
	- Winners and losers have the same goals.
	- Achieving a goal is only a momentary change. [^1]
	- Goals restrict your happiness.
	- Goals are at odds with long-term progress.


[^1]: It reminds me of a part in [[The Subtle Art of Not Giving a F*ck]]

##### 2. How Your Habits Change Your Identity
![[Untitled61_20211106201753.png]]
*The three layers of behavior change.*

1. The first layer is the **outcome**, that is concerned for the results.
2. The second layer is the **processes**, that is concerned for your system.
3. The third layer is the **identity**, that is concerned for your views and mindset.
- Changing habits is difficult for two reasons:
	1. The system is wrong.
	2. The thing you're changing is wrong.
- To change your habit effectively, focus on who you wish to become (Identity-Based Habit) instead focusing on what you want to achieve (Outcome-Based Habit).
- If mindset[^2] is just a belief, then  behind every system of actions are system of beliefs.
> The more pride you have in a particular aspect of your identity,
the more motivated you will be to maintain the habits associated with it.
- Your identity is based on your habits.
> The most practical way to change who you are is to change what you do.


- Be the best version of yourself by changing your beliefs, and upgrading and expanding your identity. 
- Habits matter because it changes your beliefs.

[^2]: Reference from [[Mindset]]
##### 3. How To Build Habits in 4 Simple Steps
- A habit is a repeated action or behavior to become automatically.
- The purpose of a habit is to solve life's problem with a little amount of energy as possible.
- Any habit can be broken down into a feedback loop that involves 4 steps:
	1. Cue
	2. Craving
	3. Response 
	4. Reward

---
- 4 Laws to make a good habit:
	1. **Make it obvious** 
	2. **Make it attractive**
	3.  **Make it easy**
	4. **Make it satisfying**
---
- 4 Laws to break a bad habit:
	1. **Make it invisible**
	2. **Make it unattractive**
	3. **Make it difficult**
	4. **Make it unsatisfying**

---

## THE FIRST LAW: Make It Obvious
##### 4. The Man Who Didn't Look Right
- With practice, our brain will pick up the cues that predict outcomes without thinking about it.
- We stop paying attention to what we are doing when habit becomes automatic.
- You need to be aware of your habits before changing them.
- Use *Pointing-and-Calling* to level up your awareness.
> ==There are no good habits or bad habits. There are only effective habits.== That is, effective at solving problems.


##### 5. The Best Way to Start a New Habit
- The two most common cues are time and location. [^3]
- You must be specific when creating an implementation intention.
- The implementation intention formula is: I will (BEHAVIOR) at (TIME) in (LOCATION).
- Use Habit Stacking to create a new habit with your existing habit.
- The habit stacking formula is: After (CURRENT HABIT), I will (NEW HABIT).


[^3]: In [[Thinking, Fast and Slow]], these are...
##### 6. Motivation Is Overrated; Environment Often Matters More


- Small changes can lead to large changes over time.
- It is easier to change your habits in a new environment.
> Our behavior is not defined by the objects in the environment but by our relationship to them.

##### 7. The Secret to Self-Control
> The people with the best self-control are typically the ones who need to use it the least.
- Use the inversion of the first law (*Make It Invisible*) to have self-control.
- One of the best ways to break a bad habit is to reduce the exposure to the influence that's causing it.
- You can't forget a habit.
- People with high self-control avoids temptations than resisting it.
- Self-control is not a long-term strategy, but a short-term.






## THE SECOND LAW: Make It Attractive

##### 8. How To Make a Habit Irresistible 
- The more attractive the thing is, the more likely it is to become a habit-forming.
- Habits are dopamine-driven feedback loop.
- It is the reward that motivates—not the fulfillment of it—that gets us to take action.
- Temptation bundling is one way to make your habits more attractive. All you need to do is to pair an action that *you want* to do with an action *you need* to do.


##### 9. The Role of Family and Friends in Shaping Your Habits
- The environment we live in determines which behavior is attractive to us.
- We tend to adopt a habit that is praised, because we humans, have a desire to fit in. It's biological. 
- Like [[Steal Like an Artist]], we tend to copy the habits of our family and friends (the close), the many (the tribe or social), and the powerful (those who we look up or the powerful). 
- Join a group with those who have your desired behavior is the normal behavior and those who you have in common.
- The power of a group overpowers the desired behavior of an individual. Because "nadala tayo sa" power of the group. [^5]
- If a behavior gets us approval and praise, it is more likely to be attractive.

[^5]: See more at [[The Laws of Human Nature]] chapter x

##### 10. How to Find and Fix the Causes of Your Bad Habits
- Attractive habits are associated with positive feelings.
- Highlight the unattractive part of a bad habit to avoid it.
- Habits are the cause of your prediction.



## THE THIRD LAW: Make It Easy
##### 11. Walk Slowly, but Never Backwards
- The more you repeat an activity, the more the brain changes its structure to be more efficient at the activity.
> Each time you repeat an action, you are activating a particular neural circuit associated with that habit.
- You'll form a habit to make it automatic by repetition.
- Focus on taking action, not in motion.


##### 12. The Law of Least Effort
- Create an environment where doing the right thing is easy.
- The lesser the friction, the easier to form a habit.
- Increase the friction with bad habits to make it difficult.
- Human behavior likes doing things that is easy. That is why (sometimes) we rely thinking intuitively than thinking with a little effort. [^5]

[^5]: [[Thinking, Fast and Slow]]

##### 13. How to Stop Procrastinating by Using the Two-Minute Rule
> the habits you follow without thinking often determine the choices you make when you are thinking.
- The *Two-Minute Rule* states that “When forming a habit *it should take less than two minutes*”
>==It’s better to do less than you hoped than to do nothing at all.==
- The more you prepare before the process, the more likely you'll slip to the state of deep focus.



##### 14. How to Make Good Habits Inevitable and Bad Habits Impossible
>==Sometimes success is less about making good habits easy and more about making bad habits hard.==
- A commitment device is your choice in present that locks in better behavior in the future.
- Onetime choices are actions that automates your future habits and deliver increasing returns over time.


## THE FOURTH LAW: Make It Satisfying
##### 15. The Cardinal Rule of Behavior Change
- The Cardinal Rule of Behavior Change is “*What is rewarded is repeated. What is punished is avoided.*”
> ==The costs of your good habits are in the present. The costs of your bad habits are in the future.==
- A habit is more likely to be repeated when it is satisfying.
- The human brain wants immediate reward rather than delayed rewards.
- To get a habit stick you need to feel immediately successful.

##### 16. How to Stick with Good Habits Every Day
- Don't break the chain. If broken once, don't repeat it twice.
- When the evidence is right in front of you, you’re less likely to lie to yourself.
- A satisfying feeling is when you make a progress.
- Just because you can measure something doesn’t mean it’s the most important thing.


##### 17. How an Accountability Partner Can Change Everything
- Knowing that someone else is watching you can be a powerful motivator.
- We usually care for the opinions around us because it helps us. Care for those opinions when coming from your family or someone who care for you. [^5]

[^5]: [[Show Your Work]]





## ADVANCED TACTICS: How to Go from Being Merely Good to Being Truly Great
##### 18. The Truth About Talent (When Genes Matter and When They Don’t)
- Play the game where the odds are in your favor. If you can't find a game, then make for yourself.
> ==Genes do not determine your destiny. They determine your areas of opportunity.==

> You don’t have to build the habits everyone tells you to build. Choose the habit that best suits you, not the one that is most popular.
- The work that hurts others, but not for you is made for you.
- The secret to maximizing your success is to choose the right field that's made for you.
- Right habit = makes your life easy
   Wrong habit = makes your life struggle
> Genes do not eliminate the need for hard work. They clarify it. 
> 
> They tell us what to work hard on.


##### 19. The Goldilocks Rule: How to Stay Motivated in Life and Work
> ==The greatest threat to success is not failure but boredom.==

> The only way to become excellent is to be endlessly fascinated by doing the same thing over and over. You have to fall in love with boredom.
##### 20. The Downside of Creating Good Habits
> The upside of habits is that we can do things without thinking. The downside is that we stop paying attention to little errors.
- Habits + Practice 40 hours a day = Mastery

##### Conclusion
- As you continue to layer small changes of top of your life, the scales of life starts to move.
>==Success is not a goal to reach or a finish line to cross. It is a system to improve, an endless process to refine.==
- A habit is a continuous process. There's no finish line to cross.

For further reading:
[[The Power of Habit]]
[[Hooked]]
[[Art and Fear]]