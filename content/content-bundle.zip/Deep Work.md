---
Author: Cal Newport
Tags: productivity
---
![[71g8BUSqbpL.jpg]]

## Introduction
**Deep Work**: *Professional activities performed in a state of distraction-free concentration that push your cognitive capabilities to their limit. These efforts create new value, improve your skill, and are hard to replicate.*

**Shallow Work**: *Noncognitively demanding, logistical-style tasks, often performed while distracted. These efforts tend to not create much new value in the world and are easy to replicate.*

>==To succeed you have to produce the absolute best stuff you’re capable of producing—a task that requires depth.==

**The Deep Work Hypothesis**: *The ability to perform deep work is becoming increasingly rare at exactly the same time it is becoming increasingly valuable in our economy. As a consequence, the few who cultivate this skill, and then make it the core of their working life, will thrive.*

## PART 1: The Idea
##### Chapter 1: Deep Work is Valuable
*Two Core Abilities for Thriving in the New Economy*:
**1.** The ability to quickly master hard things.
**2.** The ability to produce at an elite level, in terms of both quality and speed.
- If you can't produce, you can't thrive.
- Antonin-Dalmace Sertillanges's book, *[[The Intellectual Life]]*, argues that you must first dive into the relevant topics of your field to advance your understanding.
- While practicing with diffused attention, it is not a *deliberate practice.*[^1]
- ==High-Quality Work Produced = (Time Spent) x (Intensity of Focus)==
- People that switches unfinished tasks shows poor performance on the next task.
##### Chapter 2: Deep Work is Rare
**The Principle of Least Resistance**: *In a business setting, without clear feedback on the impact of various behaviors to the bottom line, we will tend toward behaviors that are easiest in the moment.*
- In *The Principle of Least Resistance*, it is similar to the law of *Make It Easy* in [[Atomic Habits]].
- Being busy is not the same as being productive.
##### Chapter 3: Deep Work Is Meaningful
- We become what we pay attention to.
- [[Flow]] is produced by [[Deep Work]].
- In the book called *[[Willpower]]*, people likes to fight for pleasure.
- 
## Part 2: Rules
##### Rule 1: Work Deeply
> The key to developing a deep work habit is to move beyond good intentions and add routines and rituals to your working life designed to minimize the amount of your limited willpower necessary to transition into and maintain a state of unbroken concentration.
- **Monastic Philosophy** is just simply a term for eliminating all distractions to maximize the dedicated time for *deep work*.
- **Bimodal Philosophy** is like time-blocking method with Parkinson's Law.
- The **Journalist Philosophy** is fitting deep work whenever you can in your schedule.
- *Dutch psychologist Ap Dijksterhuis, set out to prove that ,==some decisions are better left to your unconscious mind to untangle.==* The theory is called the **Unconcious Thought Theory**.
- **Attention Restoration Theory** proves that spending time in nature can improve your ability to concentrate. The idea is *you can restore your ability to direct your attention if you give this activity a rest.*
##### Rule 2: Embrace Boredom
> To succeed with deep work you must rewire your brain to be comfortable resisting distracting stimuli.
- To rewire your brain, you need to do Internet Sabbath or Social Media Detox once a week. As Newport said, "*==Don’t Take Breaks from Distraction. Instead Take Breaks from Focus.==*"
- Try practicing *intensity* by giving yourself a deadline or a timer.
- The secret to memorize things easily is the ability to concentrate. [^2]
##### Rule 3: Quit Social Media
**The Any-Benefit Approach to Network Tool Selection**: *You’re justified in using a network tool if you can identify any possible benefit to its use, or anything you might possibly miss out on if you don’t use it.*
> If you want to eliminate the addictive pull of entertainment sites on your time and attention, give your brain a quality alternative.

##### Rule 4: Drain the Shallow
- 

For further reading:
[[Daily Rituals]]
[[The Shallows]]
[[Hamlet's BlackBerry]]
[[The Tyranny of E-mail]]
[[The Distraction Addiction]]
[[Race Agains The Machine]]
[[Average is Over]]
[[The Intellectual Life]]
[[Outliers: The Success Story]]
[[The Talent Code]]
[[How to Become a Straight-A Student]]
[[Why Is It So Hard to Do My Work?]]
[[Getting Things Done]]
[[To Save Everything, Click Here]]
[[Rapt]]
[[Flow]]
[[All Things Shining]]
[[The Pragmatic Programmer]]
[[Willpower]] 
[[The 4 Disciplines of Execution]]
[[Moonwalking with Einstein]]
[[How to Live on 24 Hours a Day]]
[[The Innovators]]

---
### Bonus
**How to Start a Deep Work Ritual**
- Know the specific location where you'll conduct your deep work. The place must be quiet. It can be at the library.
- Consider making some rules. For example, banning any gadgets or setting a session of Pomodoro.
- How will you support your work? For example, drinking a coffee or resting.

[^1]: As K. Anders Ericsson, a professor at Florida State University, stated, *"Diffused attention is almost antithetical to the focused attention required by deliberate practice."*
[^2]: “We found that one of the biggest differences between memory athletes and the rest of us is in a cognitive ability that’s not a direct measure of memory at all but of attention,” An explanation from  research led by Henry Roediger, who runs the Memory Lab at the University of Washington in Saint Louis.