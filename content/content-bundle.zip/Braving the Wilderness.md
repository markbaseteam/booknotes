---
Author: Brené Brown
Tags:
--- 

## Chapter 1: Everywhere and Nowhere
> Sometimes the most dangerous thing for kids is the ==silence that allows them to construct their own stories—stories that almost always cast them as alone and unworthy of love and belonging.==


## Chapter 2: The Quest for True Belonging
## Chapter 3: High Lonesome: A Spiritual Crisi
## Chapter 4: People are Hard to Hate Close Up. Move In.
## Chapter 5: Speak Truth to Bullshit. Be Civil.
## Chapter 6: Hold Hands. with Strangers
## Chapter 7: Strong Back. Soft Front. Wild Heart.

---

[[Less Than Human]]
[[On Bullshit]]
[[The Gifts of Imperfection]]
[[How To Win Friends and Influence People]]
[[The Village Effect: How Face-to-Face Contact Can Make Us Healthier and Happier]]