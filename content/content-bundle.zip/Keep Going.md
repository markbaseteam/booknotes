---
Author: Austin Kleon
Tags: Creativity
---

## 1. Every Day is Ground Hog Day.
#### Take One Day at a Time.
> “None of us know what will happen. Don’t spend time worrying about it. Make the most beautiful thing you can. Try to do that every day. That’s it.”
—Laurie Anderson

> The creative life is not linear. It’s not a straight line from point A to point B. It’s more like a loop, or a spiral, in which you keep coming back to a new starting point after every project.
- It's concept is like stoicism's *memento mori.* Which has an idea that tomorrow is not promised.
#### Establish a Daily Routine.
- There's no perfect, or universal routine for creative work.
> ==What your daily routine consists of is not that important. What’s important is that the routine exists.==
#### Make Lists.
#### Finish Each Day and Be Done With It.
> Every day is like a blank page: When you’re finished filling it, you can save it, you can crumple it up, or you can slide it into the recycling bin and let it be. Only time will tell you what it was worth.
## 2. Build a Bliss Station
#### Disconnect From The World to Connect With Yourself.
#### You Can Be Woke Without Waking To The News.
> “Everybody gets so much information all day long that they lose their common sense.”—Gertrude Stein
#### Airplane Mode Can Be a Way of Life.
#### Learn To Say No.
- Learn to say "no" to protect your space and time.

## 3. Forget The Noun, Do The Verb
#### "Creative" Is Note a Noun.
- Focus on what you actually work (verb), instead of you're trying to be (noun).
#### Your Real Work is Play.
- Treat your job as a game, not as a work.
> When nothing’s fun anymore, try to make the worst thing you can.

## 4. Make Gifts
#### Protect Your Valuables.
> One of the easiest ways to hate something you love is to turn it into your job
#### Ignore The Number.
- Money, clicks, likes, followers are not the measurement for value.
#### Where There is No Gift, There is No Art
> You never know when a gift made for a single person will turn into a gift for the whole world.

## 5. The Ordinary + Extra Attention = Extraordinary
#### You Have Everything You Need
#### Slow Down And Draw Things Out
#### Pay Attention to What You Pay Attention To
> Attention is the most basic form of love.—John Tarrant.

## 6. Slay The Art Monster
#### Art is for Life. (Not The Other Way Round)
- Supposedly, art should make our lives better. If the art is destroying a life, it's not worth making.
## 7. You Are Allowed To Change Your Mind
#### To Change is To Be Alive
#### Like-Minded vs. Like-Hearted
- Hanging out with a like-minded person is comforting, but boring. Try hanging out with a like-hearted person.
#### Visit the Past

## 8. When in Doubt, Tidy Up.
#### Keep Your Tools Tidy and Materials Messy.
- Productivity and creativity are both different. You are most creative when you're not being productive.
> ==There’s a balance in a workspace between chaos and order.==
#### Tidying is Exploring.
#### Sleep Tidies Up the Brain.
#### Leave Things Better Than You Found Them.
## 9. Demons Hate Fresh Air.
#### To Exercise is to Exorcise.
## 10. Plant Your Garden.
#### Creativity Has Seasons.
> You have to pay attention to the rhythms and cycles of your creative output and learn to be patient in the off-seasons.

> ==Imitate the trees. Learn to lose in order to recover, and remember that nothing stays the same for long.==—May Sarton
#### This, Too, Shall Pass
> Every day is a potential seed that we can grow into something beautiful.


Related Books:
[[24 Hours a Day]]
[[Daily Rituals]]
[[The Gift]]
[[The Mind's Eye]]
[[How to Think]]
[[Tao Te Ching]]
[[The Life-Changing Magic of Tidying Up]]
[[Kitchen Confidential]]
[[Downhill All the Way]]