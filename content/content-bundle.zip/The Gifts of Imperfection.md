---
Author: Brené Brown
Tags: psychology, personal, spiritual
---

## Preface
- Our minds are wired to see patterns and seek meaning to it.

> How much we know and understand ourselves is critically important, but there is something that is even more essential to living a Wholehearted life: ==loving ourselves.==
- The data indicated that parents can't give their children what they don't have.

> The universe is not short on wake-up calls. ==We’re just quick to hit the snooze button.==

> No matter what gets done and how much is left undone, ==I am enough==. It’s going to bed at night thinking, Yes, I am imperfect and vulnerable and sometimes afraid, but that doesn’t change the truth that I am also brave and worthy of love and belonging.

- Wholeheartedly living doesn't have a finish line. It is a journey of a lifetime.

## Courage, Compassion, and Connection: The Gifts of Imperfection
- Shame hates you when you share your shaming story.

> Courage originally meant ==“To speak one’s mind by telling all one’s heart.”==

> The heart of compassion is really acceptance. The better we are at accepting ourselves and others, the more compassionate we become.

- Practice acceptance and compassion with boundaries and accountability.

- Humans are wired to connect.

> In our technology-crazed world, we’ve confused being communicative with feeling connected. Just because we’re plugged in, doesn’t mean we feel seen and heard.

- The world is not divided into “those who offer help” and “those who need help.” The truth is we are both.

## Exploring the Power of Love, Belonging, and Feeling Enough
- We will fully experience love and belonging if we feel that we're *worthy* of love and belonging.
- **Fitting in** is about becoming who you *need* to be to be accepted. **Belonging** doesn't require us to change. We just need to be ourselves.

> Everyone who risks explaining love and belonging is hopefully doing the best they can to answer an unanswerable question.

> We are biologically, cognitively, physically, and spiritually wired to love, to be loved, and to belong.

> **Love**:
We cultivate love when we allow our most vulnerable and powerful selves to be deeply seen and known, and when we honor the spiritual connection that grows from that offering with trust, respect, kindness, and affection.
==Love is not something we give or get; it is something that we nurture and grow, a connection that can only be cultivated between two people when it exists within each one of them—we can only love others as much as we love ourselves.==
Shame, blame, disrespect, betrayal, and the withholding of affection damage the roots from which love grows. Love can only survive these injuries if they are acknowledged, healed, and rare.

> **Belonging**:
Belonging is the innate human desire to be part of something larger than us. Because this yearning is so primal, we often try to acquire it by fitting in and by seeking approval, which are not only hollow substitutes for belonging, but often barriers to it. ==Because true belonging only happens when we present our authentic, imperfect selves to the world, our sense of belonging can never be greater than our level of self-acceptance.==

- Self-love is respecting ourselves, trusting ourselves, and being kind and affectionate to ourselves.

## The Things That Get in a Way
> If we want to live and love with our whole hearts, and if we want to engage with the world from a place of worthiness, ==we have to talk about the things that get in the way—especially shame, fear, and vulnerability.==

- The difference between guilt and shame:
	- **Shame** = I am bad.
	- **Guilt** = I did something bad.

## Guidepost # 1 - Cultivating Authenticity: Letting Go of What People Think
- Authenticity is not something that we already have or don't have. It's practiced.
> Authenticity is the daily practice of letting go of who we think we’re supposed to be and embracing who we are.

> Staying vulnerable is a risk we have to take if we want to experience connection.

## Guidepost # 2 - Cultivating Self-Compassion: Letting Go of Perfectionism
- Shame is the birthplace of perfectionism.
- Claim shame before it claims you.
- Perfectionism and striving to be your best is not the same.
- **Perfectionism is:**
	- Self-destructive because there's no such thing as perfect.
	- Belief system
	- Addictive because when we experience shame, judgment, and blame, we often believe it’s because we weren’t perfect enough.

> To overcome perfectionism, we need to be able to acknowledge our vulnerabilities to the universal experiences of shame, judgment, and blame; develop shame resilience; and practice self-compassion

- Perfectionism occurs when the person is vulnerable or with compulsive chronic.

## Guidepost # 3 - Cultivating a Resilient Spirit: Letting Go of Numbing and Powerlessness
- The one thing that people with religion or with no religion have in common is resilience as their foundation.

> ... hope is not an emotion; it’s a way of thinking or a cognitive process.

> Practicing spirituality is what brings healing and creates resilience

## Guidepost # 4 - Cultivating Gratitude and Joy: Letting Go of Scarcity and Fear of The Dark
- Joy and happiness are not the same experience.
	- Happiness is tied to circumstance (external) and joyfulness is tied to spirit and gratitude (internal).

> The dark does not destroy the light; it defines it. It’s our fear of the dark that casts our joy into the shadows.

## Guidepost # 5 - Cultivating Intuition and Trusting Faith: Letting Go of The Need of Certainty
> Intuition is not a single way of knowing—it’s our ability to hold space for uncertainty and our willingness to trust the many ways we’ve developed knowledge and insight, including instinct, experience, faith, and reason.

> Faith is a place of mystery, where we find the courage to believe in what we cannot see and the strength to let go of our fear of uncertainty.

> To say, “I’m going to engage Wholeheartedly in my life” requires believing without seeing.

## Guidepost # 6 - Cultivating Creativity: Letting Go of Comparison
> There’s no such thing as creative people and non-creative people. ==There are only people who use their creativity and people who don’t.==

> As long as we’re creating, we’re cultivating meaning.

> Creativity, which is the expression of our originality, helps us stay mindful that what we bring to the world is completely original and cannot be compared.

## Guidepost # 7 - Cultivating Play and Rest: Letting Go of Exhaustion as a Status Symbol and Productivity as a Self-Worth

## Guidepost # 8 - Cultivating Calm and Stillness: Letting Go of Anxiety as a Lifestyle
- Calm - creating perspective and mindfulness while managing emotional reactivity.

> Stillness is not about focusing on nothingness; it’s about creating a clearing. It’s opening up an emotionally clutter-free space and allowing ourselves to feel and think and dream and question.

## Guidepost # 9 - Cultivating Meaningful Work: Letting Go of Self-Doubt and "Supposed To"
> God lives within us, not above us.

> We all have gifts and talents. When we cultivate those gifts and share them with the world, we create a sense of meaning and purpose in our lives.

- Our gifts and talents have a unique meaning to each one of us. Because no one can define what's meaningful for us.

> “Don’t ask what the world needs. Ask what makes you come alive, and go do it. Because what the world needs is people who have come alive.”—Howard Thurman

## Guidepost # 10 - Cultivating Laughter, Song, and Dance: Letting Go of Being Cool and "Always in Control"
> Knowing laughter embodies the relief and connection we experience when we realize the power of sharing our stories—==we’re not laughing at each other but with each other ==

Related books:
[[How It Shapes the Brain, Opens the Imagination, and Invigorates the Soul]]
[[Social Intelligence: The New Science of Human Relationships]]
[[I Thought It Was Just Me]]
[[The Happiness Project]]
[[Happier]]
[[The Soul of Money]]
[[When the Heart Waits]]
[[Comfortable with Uncertainty]]
[[The Alchemist]]
[[Play: How It Shapes the Brain, Opens the Imagination, and Invigorates the Soul.]]
[[The Dance of Connection]]
[[One Person/Multiple Careers: A New Model for Work/Life Success.]]
[[Outliers: The Success Story]]
[[Dancing in the Streets: A History of Collective Joy]]